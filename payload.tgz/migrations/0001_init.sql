PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS sources (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('browser', 'json-feed', 'manual')),
  url TEXT,
  enabled INTEGER NOT NULL DEFAULT 1 CHECK (enabled IN (0, 1)),
  config_json TEXT NOT NULL DEFAULT '{}',
  last_collected_at TEXT,
  last_status TEXT,
  last_error TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS pipeline_runs (
  id TEXT PRIMARY KEY,
  trigger_type TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('queued', 'running', 'completed', 'partial', 'failed')),
  started_at TEXT NOT NULL,
  finished_at TEXT,
  stats_json TEXT NOT NULL DEFAULT '{}',
  error TEXT
);

CREATE TABLE IF NOT EXISTS raw_snapshots (
  id TEXT PRIMARY KEY,
  source_id TEXT NOT NULL REFERENCES sources(id) ON DELETE CASCADE,
  run_id TEXT REFERENCES pipeline_runs(id) ON DELETE SET NULL,
  captured_at TEXT NOT NULL,
  content_hash TEXT NOT NULL,
  r2_key TEXT NOT NULL,
  mime_type TEXT NOT NULL,
  title TEXT,
  url TEXT,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_snapshots_source_time
  ON raw_snapshots(source_id, captured_at DESC);

CREATE TABLE IF NOT EXISTS creatives (
  id TEXT PRIMARY KEY,
  source_id TEXT NOT NULL REFERENCES sources(id) ON DELETE RESTRICT,
  external_id TEXT,
  canonical_url TEXT,
  title TEXT NOT NULL,
  advertiser TEXT,
  platform TEXT,
  industry TEXT,
  media_type TEXT NOT NULL DEFAULT 'unknown',
  media_url TEXT,
  first_seen_at TEXT NOT NULL,
  last_seen_at TEXT NOT NULL,
  active_days INTEGER NOT NULL DEFAULT 1,
  rank_current REAL,
  rank_previous REAL,
  rank_delta REAL NOT NULL DEFAULT 0,
  content_hash TEXT NOT NULL,
  raw_text TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'new' CHECK (status IN ('new', 'queued', 'analyzed', 'failed', 'ignored')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(source_id, external_id),
  UNIQUE(source_id, content_hash)
);

CREATE INDEX IF NOT EXISTS idx_creatives_last_seen
  ON creatives(last_seen_at DESC);
CREATE INDEX IF NOT EXISTS idx_creatives_rank_delta
  ON creatives(rank_delta DESC);
CREATE INDEX IF NOT EXISTS idx_creatives_status
  ON creatives(status);
CREATE INDEX IF NOT EXISTS idx_creatives_industry
  ON creatives(industry);

CREATE TABLE IF NOT EXISTS creative_observations (
  id TEXT PRIMARY KEY,
  creative_id TEXT NOT NULL REFERENCES creatives(id) ON DELETE CASCADE,
  observed_at TEXT NOT NULL,
  rank_value REAL,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_observations_creative_time
  ON creative_observations(creative_id, observed_at DESC);

CREATE TABLE IF NOT EXISTS creative_analyses (
  creative_id TEXT PRIMARY KEY REFERENCES creatives(id) ON DELETE CASCADE,
  schema_version INTEGER NOT NULL,
  model TEXT NOT NULL,
  summary TEXT NOT NULL,
  hook_type TEXT NOT NULL,
  hook_text TEXT NOT NULL,
  audience_primary TEXT NOT NULL,
  gameplay_primary TEXT NOT NULL,
  education_primary TEXT NOT NULL,
  cta TEXT NOT NULL,
  emotional_levers_json TEXT NOT NULL DEFAULT '[]',
  game_mechanics_json TEXT NOT NULL DEFAULT '[]',
  education_constructs_json TEXT NOT NULL DEFAULT '[]',
  risk_flags_json TEXT NOT NULL DEFAULT '[]',
  risk_score REAL NOT NULL DEFAULT 0,
  confidence REAL NOT NULL DEFAULT 0,
  analysis_json TEXT NOT NULL,
  analyzed_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_analysis_gameplay
  ON creative_analyses(gameplay_primary);
CREATE INDEX IF NOT EXISTS idx_analysis_audience
  ON creative_analyses(audience_primary);
CREATE INDEX IF NOT EXISTS idx_analysis_hook
  ON creative_analyses(hook_type);

CREATE TABLE IF NOT EXISTS clusters (
  id TEXT PRIMARY KEY,
  kind TEXT NOT NULL CHECK (kind IN ('hook', 'gameplay', 'audience')),
  label TEXT NOT NULL,
  summary TEXT NOT NULL,
  score REAL NOT NULL DEFAULT 0,
  sample_count INTEGER NOT NULL DEFAULT 0,
  first_seen_at TEXT NOT NULL,
  last_seen_at TEXT NOT NULL,
  trend_json TEXT NOT NULL DEFAULT '{}',
  updated_at TEXT NOT NULL,
  UNIQUE(kind, label)
);

CREATE TABLE IF NOT EXISTS cluster_members (
  cluster_id TEXT NOT NULL REFERENCES clusters(id) ON DELETE CASCADE,
  creative_id TEXT NOT NULL REFERENCES creatives(id) ON DELETE CASCADE,
  weight REAL NOT NULL DEFAULT 1,
  PRIMARY KEY(cluster_id, creative_id)
);

CREATE TABLE IF NOT EXISTS digests (
  id TEXT PRIMARY KEY,
  period TEXT NOT NULL CHECK (period IN ('daily', 'weekly', 'monthly')),
  window_start TEXT NOT NULL,
  window_end TEXT NOT NULL,
  title TEXT NOT NULL,
  summary TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_digests_period_time
  ON digests(period, created_at DESC);

CREATE TABLE IF NOT EXISTS opportunities (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  audience TEXT NOT NULL,
  ad_shell TEXT NOT NULL,
  core_gameplay TEXT NOT NULL,
  education_constructs_json TEXT NOT NULL DEFAULT '[]',
  evidence_json TEXT NOT NULL DEFAULT '[]',
  score REAL NOT NULL,
  confidence REAL NOT NULL,
  risk_summary TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'candidate' CHECK (status IN ('candidate', 'watching', 'approved', 'rejected')),
  decision_note TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_opportunities_status_score
  ON opportunities(status, score DESC);

CREATE TABLE IF NOT EXISTS audit_log (
  id TEXT PRIMARY KEY,
  actor TEXT NOT NULL,
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  payload_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL
);

INSERT OR IGNORE INTO sources (
  id, name, kind, url, enabled, config_json, created_at, updated_at
) VALUES (
  'admuse-idea',
  '腾讯妙思｜获得灵感',
  'browser',
  'https://admuse.qq.com/#/idea',
  1,
  '{"maxCards":30,"waitMs":7000,"selectors":{"card":"article,[class*=creative-card],[class*=material-card],[class*=idea-card],[class*=card]","title":"h1,h2,h3,[class*=title]","advertiser":"[class*=advertiser],[class*=account],[class*=author]","link":"a[href]","image":"img","video":"video","rank":"[class*=rank],[class*=index]"}}',
  datetime('now'),
  datetime('now')
);

INSERT OR IGNORE INTO sources (
  id, name, kind, url, enabled, config_json, created_at, updated_at
) VALUES (
  'manual-import',
  '人工导入',
  'manual',
  NULL,
  1,
  '{}',
  datetime('now'),
  datetime('now')
);
